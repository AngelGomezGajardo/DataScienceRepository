archivo = open("archivo_ejemplo2.csv")

archivo_en_lineas = archivo.readlines()

archivo.close()

numero_de_clientes = len(archivo_en_lineas)

matriz_de_datos = []

for linea in archivo_en_lineas:
	linea = linea.strip()
	fila = linea.split(";")
	matriz_de_datos.append(fila)

print(matriz_de_datos)

for fila in matriz_de_datos:
	fecha_de_nacimiento = fila[3]
	fecha_de_nacimiento_lista = fecha_de_nacimiento.split("/")
	edad = 2018 - int(fecha_de_nacimiento_lista[0])
	fila.append(edad)

print(matriz_de_datos)

archivo_guardar = open("ejemplo_con_edad.csv","w")

for fila in matriz_de_datos:
	fila_para_escribir = ""

	for i in range(0,len(fila)):
		if i == len(fila)-1:
			fila_para_escribir += str(fila[i])
		else:
			fila_para_escribir += fila[i] + ";"

	fila_para_escribir += "\n"

	archivo_guardar.write(fila_para_escribir)

archivo_guardar.close()