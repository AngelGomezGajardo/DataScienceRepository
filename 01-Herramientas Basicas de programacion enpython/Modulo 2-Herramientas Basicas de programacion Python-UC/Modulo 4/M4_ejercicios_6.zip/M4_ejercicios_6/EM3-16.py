archivo = open("archivo_ejemplo2.csv")

archivo_en_lineas = archivo.readlines()

archivo.close()

numero_de_clientes = len(archivo_en_lineas)

matriz_de_datos = []

for linea in archivo_en_lineas:
	linea = linea.strip()
	fila = linea.split(";")
	matriz_de_datos.append(fila)

print(matriz_de_datos)

for fila in matriz_de_datos:
	fecha_de_nacimiento = fila[3]
	fecha_de_nacimiento_lista = fecha_de_nacimiento.split("/")
	edad = 2018 - int(fecha_de_nacimiento_lista[0])
	fila.append(edad)

print(matriz_de_datos)