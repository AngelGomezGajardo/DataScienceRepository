archivo = open("archivo_ejemplo2.csv")

archivo_en_lineas = archivo.readlines()

archivo.close()

numero_de_clientes = len(archivo_en_lineas)

matriz_de_datos = []

for linea in archivo_en_lineas:
	linea = linea.strip()
	fila = linea.split(";")
	matriz_de_datos.append(fila)

print(matriz_de_datos)

for fila in matriz_de_datos:
	valor_tipo_cliente = fila[4]
	fila[4] = valor_tipo_cliente[len(valor_tipo_cliente)-1]

print(matriz_de_datos)