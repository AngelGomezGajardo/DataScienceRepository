informacion_archivo = open("ejemplo1.txt","r",encoding="UTF-8")

lineas = informacion_archivo.readlines()

informacion_archivo.close()

for linea in lineas:
	print(linea)