informacion_archivo = open("ejemplo1.txt",encoding="UTF-8")

lineas = informacion_archivo.readlines()

for linea in lineas:
	print(linea)