informacion_archivo = open("ejemplo1.txt")
print(informacion_archivo)