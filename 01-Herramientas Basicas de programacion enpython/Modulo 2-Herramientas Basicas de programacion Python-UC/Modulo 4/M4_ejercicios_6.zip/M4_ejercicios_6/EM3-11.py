informacion_archivo = open("ejemplo1b.txt","w",encoding="UTF-8")

informacion_archivo.write("\nAtte, Felipe López")

informacion_archivo.close()