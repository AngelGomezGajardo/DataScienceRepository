archivo = open("archivo_ejemplo.csv")

archivo_en_lineas = archivo.readlines()

numero_de_clientes = len(archivo_en_lineas)

matriz_de_datos = []


for linea in archivo_en_lineas:
	fila = linea.split(";")
	matriz_de_datos.append(fila)

print(matriz_de_datos)

for fila in matriz_de_datos:
	fila[7]=fila[7].strip()

print(matriz_de_datos)