informacion_archivo = open("ejemplo1.txt",encoding="UTF-8")
print(informacion_archivo.read())