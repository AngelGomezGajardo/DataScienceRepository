informacion_archivo = open("ejemplo_nuevo.txt","w",encoding="UTF-8")

informacion_archivo.write("Mi nombre es:")

informacion_archivo.write("Felipe López")

informacion_archivo.close()