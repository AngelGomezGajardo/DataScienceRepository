informacion_archivo = open("ejemplo1a.txt","a",encoding="UTF-8")

informacion_archivo.write("\nAtte, Felipe López")

informacion_archivo.close()