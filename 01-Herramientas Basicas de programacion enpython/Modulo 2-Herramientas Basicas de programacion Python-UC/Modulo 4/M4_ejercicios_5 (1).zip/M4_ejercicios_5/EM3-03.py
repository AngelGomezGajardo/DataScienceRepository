matriz2 = [["a","b","c"],["d","e","f"],["g","h","i"],["j","k","l"]]
print("Filas:",len(matriz2))
print("Columnas:",len(matriz2[0]))