matriz = [["a","b","c"],["d","e","f"],["g","h","i"]]
print(matriz)
matriz[2][1] = "z"
print(matriz)