matriz = [["a","b","c"],["d","e","f"],["g","h","i"]]
print(matriz[1][2])