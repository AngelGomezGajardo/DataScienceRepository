def suma_de_dos_numeros(num1, num2):
	return num1 + num2