def suma_de_dos_numeros(num1, num2):
	variable_con_valor_retornado = num1 + num2
	return variable_con_valor_retornado