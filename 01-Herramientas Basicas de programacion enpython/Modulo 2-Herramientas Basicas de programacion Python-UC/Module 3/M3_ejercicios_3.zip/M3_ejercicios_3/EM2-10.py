def sumar_tres_numeros(numero_a,numero_b,numero_c):
	return numero_a+numero_b+numero_c
print(numero_a)

variable1=20
variable2=45
variable3=-8

resultado = sumar_tres_numeros(variable1,variable2,variable3)
print(resultado)