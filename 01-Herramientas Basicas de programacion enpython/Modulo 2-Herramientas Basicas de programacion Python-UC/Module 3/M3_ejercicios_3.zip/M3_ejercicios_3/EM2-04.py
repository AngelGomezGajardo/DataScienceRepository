variable_tipo_bool = True
variable_tipo_bool2 = False