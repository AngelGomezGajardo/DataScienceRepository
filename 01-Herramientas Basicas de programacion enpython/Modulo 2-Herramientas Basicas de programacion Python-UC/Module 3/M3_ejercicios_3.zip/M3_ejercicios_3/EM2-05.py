numero = 2

variable_bool1 = numero != 2
variable_bool2 = numero == 2
variable_bool3 = variable_bool1 and variable_bool2