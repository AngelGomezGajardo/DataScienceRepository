def multiplicar_tres_numeros(numero_a,numero_b,numero_c):
	return numero_a*numero_b*numero_c

def sacar_promedio_entre_dos(primer_numero,segundo_numero):
	return (primer_numero+segundo_numero)/2

variable1=2
variable2=4
variable3=1

resultado1 = multiplicar_tres_numeros(variable1,variable2,variable3)+sacar_promedio_entre_dos(variable1,variable2)
print(resultado1)

resultado2 = sacar_promedio_entre_dos(multiplicar_tres_numeros(variable1,variable2,variable3),variable2)
print(resultado2)