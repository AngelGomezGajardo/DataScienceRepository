lista1 = ["administración","ventas","operaciones","servicio al cliente","marketing"]
lista2 = ["finanzas","contabilidad"]
print(lista1)
lista1.extend(lista2)
print(lista1)