lista1 = ["administración","ventas","operaciones","post-venta"]
print(lista1)
lista1[3] = "servicio al cliente"
print(lista1)