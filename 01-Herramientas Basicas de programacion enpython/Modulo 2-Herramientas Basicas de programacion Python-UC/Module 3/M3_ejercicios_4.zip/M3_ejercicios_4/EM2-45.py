lista1 = ["administración","ventas","ventas","ventas","marketing"]
print(lista1.count("ventas"))