string_de_ejemplo = "Hola"
print(len(string_de_ejemplo))

string_de_ejemplo2 = "Hola cómo estás"
print(len(string_de_ejemplo2))