variable1="a"
variable2="b"

print(variable1 < variable2)
print(variable1 > variable2)