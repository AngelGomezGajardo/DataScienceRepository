s = "papapapepa"
print(s.find("pe"))