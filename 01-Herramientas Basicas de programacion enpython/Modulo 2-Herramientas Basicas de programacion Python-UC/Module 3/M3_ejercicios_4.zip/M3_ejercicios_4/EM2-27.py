s = "papapapepa"
print(s.count("pa"))