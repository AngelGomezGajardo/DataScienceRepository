lista1 = ["administración","ventas","operaciones","post-venta"]
elemento = lista1[2]
print(elemento)