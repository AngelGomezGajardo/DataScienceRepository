variable_texto="este es un texto de ejemplo"
print(variable_texto)