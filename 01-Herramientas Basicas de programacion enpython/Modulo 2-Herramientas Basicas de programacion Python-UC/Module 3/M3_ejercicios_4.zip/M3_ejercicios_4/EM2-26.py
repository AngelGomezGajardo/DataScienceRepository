s = "palabra"
print(s.count("a"))