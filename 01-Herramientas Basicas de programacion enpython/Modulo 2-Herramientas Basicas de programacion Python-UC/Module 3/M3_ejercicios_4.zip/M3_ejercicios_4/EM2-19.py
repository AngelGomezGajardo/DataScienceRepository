texto_ingresado_por_el_usuario = input("Ingrese un texto cualquier. Python imprimirá el último caracter de este texto\n")

largo_texto = len(texto_ingresado_por_el_usuario)

ultimo_caracter = texto_ingresado_por_el_usuario[largo_texto-1]

print(ultimo_caracter)