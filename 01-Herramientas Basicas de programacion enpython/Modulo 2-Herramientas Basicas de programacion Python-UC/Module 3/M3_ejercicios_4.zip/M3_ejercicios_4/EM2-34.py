s = "\nPALABRA "
print(s.strip())