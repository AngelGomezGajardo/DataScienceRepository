s = "palabra"
print(s.replace("a","b"))