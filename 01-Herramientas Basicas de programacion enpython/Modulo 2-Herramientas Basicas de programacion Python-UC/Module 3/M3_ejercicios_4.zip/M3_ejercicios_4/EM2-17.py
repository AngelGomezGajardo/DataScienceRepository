texto1 = "Los datos"
texto2 = "Móvil"

print(texto1[4] + texto2[2])