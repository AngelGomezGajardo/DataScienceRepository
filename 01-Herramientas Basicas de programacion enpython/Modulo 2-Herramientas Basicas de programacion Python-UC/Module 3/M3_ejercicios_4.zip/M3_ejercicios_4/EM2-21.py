nombre = "Andrés José Pérez Rojas"
print(nombre[12:17])