lista1 = ["administración","ventas","operaciones","servicio al cliente","marketing"]
print(lista1)
lista1.pop(2)
print(lista1)