string_de_ejemplo = "texto de ejemplo"
primera_palabra = string_de_ejemplo[0:5]
print(primera_palabra)

segunda_palabra = string_de_ejemplo[6:8]
print(segunda_palabra)

ultima_palabra = string_de_ejemplo[9:16]
print(ultima_palabra)