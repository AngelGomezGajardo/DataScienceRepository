variable_de_texto1 = "Podemos unir"
variable_de_texto2 = "dos textos distintos"

concatenacion = variable_de_texto1 + variable_de_texto2
print(concatenacion)