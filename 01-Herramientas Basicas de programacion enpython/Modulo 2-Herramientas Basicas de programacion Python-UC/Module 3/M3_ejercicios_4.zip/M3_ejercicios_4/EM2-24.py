variable1="ejemploa"
variable2="ejemplob"

print(variable1 < variable2)
print(variable1 > variable2)