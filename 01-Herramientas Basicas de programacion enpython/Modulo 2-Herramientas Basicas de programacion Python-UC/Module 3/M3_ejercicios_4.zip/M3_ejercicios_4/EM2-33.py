s = "PALABRA"
print(s.lower())