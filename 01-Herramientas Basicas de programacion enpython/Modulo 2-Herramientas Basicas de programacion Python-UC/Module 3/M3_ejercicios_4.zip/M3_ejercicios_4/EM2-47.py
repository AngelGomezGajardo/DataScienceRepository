lista1 = ["administración","ventas","operaciones","servicio al cliente"]
print(lista1)
lista1.sort()
print(lista1)