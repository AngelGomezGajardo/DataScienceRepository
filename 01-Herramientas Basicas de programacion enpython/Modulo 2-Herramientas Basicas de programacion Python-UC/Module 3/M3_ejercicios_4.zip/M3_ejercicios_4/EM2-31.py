s = "papapapepa"
print(s.replace("pa","tx"))