lista1 = ["administración","ventas","operaciones","servicio al cliente"]
for i in lista1:
	print(i)