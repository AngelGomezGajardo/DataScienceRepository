s = "palabra"
print(s.upper())