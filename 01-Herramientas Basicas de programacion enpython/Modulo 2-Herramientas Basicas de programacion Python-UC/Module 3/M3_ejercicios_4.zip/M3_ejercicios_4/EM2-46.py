lista1 = ["administración","ventas","operaciones","servicio al cliente"]
print(lista1.index("operaciones"))