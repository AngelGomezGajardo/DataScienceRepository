s = "palabra"
print(s.find("a"))