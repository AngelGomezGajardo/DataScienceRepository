texto1 = "Los datos"
texto2 = "Móvil"

cuarta_letra_texto1 = texto1[3]
segunda_letra_texto2 = texto2[1]

print(cuarta_letra_texto1 + segunda_letra_texto2)