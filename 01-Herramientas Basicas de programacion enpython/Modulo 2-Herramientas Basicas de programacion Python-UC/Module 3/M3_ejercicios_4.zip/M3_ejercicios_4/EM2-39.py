lista1 = ["administración","ventas","operaciones","post-venta"]
elementos = lista1[0:2]
print(elementos)