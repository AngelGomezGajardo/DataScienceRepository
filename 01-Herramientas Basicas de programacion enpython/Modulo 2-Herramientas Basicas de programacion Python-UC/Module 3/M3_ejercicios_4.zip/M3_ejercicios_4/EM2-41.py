lista1 = ["administración","ventas","operaciones","servicio al cliente"]
print(lista1)
lista1.append("marketing")
print(lista1)