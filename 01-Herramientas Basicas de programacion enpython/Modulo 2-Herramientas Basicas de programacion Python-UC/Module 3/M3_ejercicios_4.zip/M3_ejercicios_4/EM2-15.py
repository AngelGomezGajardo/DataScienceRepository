s = "hola"
print(s[0])