s="ejemplo"
for i in s:
	print(i)