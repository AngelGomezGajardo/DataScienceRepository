variable1="López"
variable2="Pérez"

print(variable1 < variable2)
print(variable1 > variable2)