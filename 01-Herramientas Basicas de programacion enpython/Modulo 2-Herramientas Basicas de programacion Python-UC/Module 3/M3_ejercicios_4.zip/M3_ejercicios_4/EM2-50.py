nombres_trabajadores = input("Ingrese el nombre de los trabajadores del departamento de ventas\n")
print(nombres_trabajadores)
print(nombres_trabajadores.split(","))