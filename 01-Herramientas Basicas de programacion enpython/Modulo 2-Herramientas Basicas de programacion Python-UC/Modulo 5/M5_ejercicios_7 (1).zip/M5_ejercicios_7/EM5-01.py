unaLista = [12, 34, 21]
print(unaLista[0])
print(unaLista[1])
print(unaLista[2])