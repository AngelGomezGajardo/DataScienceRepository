lista = [(1, 2, 3), (4, 5, 6), (7, 8, 9)]
for tupla in lista:
  x, y, z = tupla
  print (x)