unDiccionario = {'primero':12, 'segundo':34, 'tercero':21}
print()
print(unDiccionario['primero'])
print(unDiccionario['segundo'])
print(unDiccionario['tercero'])