unaLista = [12, 34, 21]
print(unaLista[0])
print(unaLista[1])
print(unaLista[2])
for item in unaLista:
    print(item)