unDiccionario = {'primero':12, 'segundo':34, 'tercero':21}
print(len(unDiccionario))