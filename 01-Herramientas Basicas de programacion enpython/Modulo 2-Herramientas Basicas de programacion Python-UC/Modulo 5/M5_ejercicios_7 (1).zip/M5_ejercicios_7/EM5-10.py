d = {'uno': 1, 'dos': 2}
for i in d.items():
  print(i)
for k, v in d.items():
  print (k, v)