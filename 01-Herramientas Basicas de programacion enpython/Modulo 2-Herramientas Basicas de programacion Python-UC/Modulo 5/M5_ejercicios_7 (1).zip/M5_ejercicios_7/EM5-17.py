tupla = ([1, 2, 3], [4, 5, 6], [7, 8, 9])
for i in range(0, 3):
    print (tupla[i])
    l = tupla[i]
    for j in l:
         print (j)