unDiccionario = {'primero':12, 'segundo':34, 'tercero':21}
for item in unDiccionario.items():
    print(item)