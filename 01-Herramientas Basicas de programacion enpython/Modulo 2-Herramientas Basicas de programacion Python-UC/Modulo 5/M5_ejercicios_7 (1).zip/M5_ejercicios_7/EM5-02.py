for item in unaLista:
  print (item)