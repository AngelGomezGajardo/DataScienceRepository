unDiccionario = {'primero':12, 'segundo':34, 'tercero':21}
unDiccionario['segundo'] = 'Ahora es un string'
unDiccionario['cuarto'] = 98
print (unDiccionario)