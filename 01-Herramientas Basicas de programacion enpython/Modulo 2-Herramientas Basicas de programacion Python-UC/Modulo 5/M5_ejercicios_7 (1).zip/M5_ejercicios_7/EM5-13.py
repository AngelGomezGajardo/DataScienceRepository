unaTupla = (12, 34, 21)
print(unaTupla)