unDiccionario = {'primero': 12, 'segundo': 'Ahora es un string', 'tercero': 21, 'cuarto': 98}
del unDiccionario['segundo']
print(unDiccionario)
unDiccionario['segundo'] = 'recuperado'
print(unDiccionario)