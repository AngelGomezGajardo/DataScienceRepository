unaTupla = (12, 34, 21)
print(unaTupla)
print (unaTupla[0], unaTupla[1],  unaTupla[2])