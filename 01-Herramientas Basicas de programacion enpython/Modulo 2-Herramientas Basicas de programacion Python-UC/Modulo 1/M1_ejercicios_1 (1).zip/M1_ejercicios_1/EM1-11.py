casa=1
print(casa)

perro=8/2
print(perro)

perro_grande1=28
print(perro_grande1)