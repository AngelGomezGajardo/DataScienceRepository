variable1=2
print(variable1)