variable2=30*50
print(variable2)