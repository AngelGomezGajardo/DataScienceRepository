variable_entera=-9
print(variable_entera)