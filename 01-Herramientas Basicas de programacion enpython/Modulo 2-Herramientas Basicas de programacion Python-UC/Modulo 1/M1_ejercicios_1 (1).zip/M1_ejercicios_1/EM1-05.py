print(12/4)

print(4/12)