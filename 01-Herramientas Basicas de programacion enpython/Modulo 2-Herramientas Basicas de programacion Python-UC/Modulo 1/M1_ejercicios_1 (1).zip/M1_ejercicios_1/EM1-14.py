variable_decimal=8.75
print(variable_decimal)