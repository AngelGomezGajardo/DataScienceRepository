print(4+7)

print(1001+817)