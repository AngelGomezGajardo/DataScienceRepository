precio_dolar=int(input("Ingresa el precio del dolar:\n"))
cantidad_de_dolares=int(input("Ingresa la cantidad de dolares por cambiar:\n"))
cantidad_en_pesos=precio_dolar*cantidad_de_dolares
print(cantidad_en_pesos)