print(5*8)

print(25*0)