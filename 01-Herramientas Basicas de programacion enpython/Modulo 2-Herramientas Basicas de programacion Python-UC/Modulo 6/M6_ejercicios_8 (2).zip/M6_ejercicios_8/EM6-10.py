def func2(x=0, y=0, z=0):
  return x + 2 * y + 3 * z

value = func2(1, 2, 3)
print(value)

value = func2(1, 2)
print(value)

value = func2(1)
print(value)

value = func2()
print(value)