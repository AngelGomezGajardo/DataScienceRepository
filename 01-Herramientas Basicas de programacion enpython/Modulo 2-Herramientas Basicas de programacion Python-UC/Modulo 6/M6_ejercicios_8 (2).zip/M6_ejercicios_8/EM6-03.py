x = 10
def func2(y):
  print(y)
  x = 1
func2(x)
func2(x)