x = [10, 20, 30]
def pick_first(x):
  print(x)
  x[0] = 0

pick_first(x)
pick_first(x)