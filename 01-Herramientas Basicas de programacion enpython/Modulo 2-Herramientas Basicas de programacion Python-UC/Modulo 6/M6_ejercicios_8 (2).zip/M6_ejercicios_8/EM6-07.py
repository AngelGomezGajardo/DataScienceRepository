def  sum3(x, y, z):
  w = x + y + z
  return w
print (sum3(1,3,5))
print (sum3(1,2,sum3(3, 4, 5)))