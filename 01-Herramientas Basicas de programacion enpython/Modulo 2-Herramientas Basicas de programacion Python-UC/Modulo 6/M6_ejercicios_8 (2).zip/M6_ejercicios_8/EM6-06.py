x = {'a':10, 'b':20, 'c':30}
def pick_b(x):
  print(x['b'])
  x['b'] = 100

pick_b(x)
pick_b(x)