x = 10
def func1(y):
  print(y)
func1(x)
func1(2 * x)