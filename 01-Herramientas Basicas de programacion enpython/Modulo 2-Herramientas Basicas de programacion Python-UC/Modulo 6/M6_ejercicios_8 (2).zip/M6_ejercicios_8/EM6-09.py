def func2(x, y, z):
   return x + 2 * y + 3 * z

value = func2(1, 2, 3)
print(value)

value = func2(z=3, x=1, y=2)
print(value)