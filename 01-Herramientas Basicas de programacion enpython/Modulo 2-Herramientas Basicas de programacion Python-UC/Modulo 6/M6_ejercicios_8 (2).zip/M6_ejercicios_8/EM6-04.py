x = 10
def func3(y):
  y = y + 1
  print(y)
func3(x)
print(y)