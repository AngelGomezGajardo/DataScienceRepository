#puede retornar + de 1 valor en forma de tupla
def first_and_third(x, y, z):
  return x, z

x, y  = first_and_third('esto','no','funciona')
print(x + " " + y)