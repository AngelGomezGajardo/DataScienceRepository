def sumar(a, b):
    return(a + b)
result = sumar(23, 20)
result = sumar(12, 18)